# Make a simple calculator that can add, subtract, multiply and divide using functions
# This function adds two numbers
class Calculator:
    def add(self,x, y):
        return x + y
# This function subtracts two numbers
    def subtract(self,x, y):
        return x - y
# This function multiplies two numbers
    def multiply(self,x, y):
        return x * y
# This function divides two numbers
    def divide(self,x, y):
        return x / y